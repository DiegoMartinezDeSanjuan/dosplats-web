# Dos Plats Web

Proyecto de página web para el restaurante **Dos Plats (Lleida)**, con **Next.js** y **Supabase**.

## Características
- Visualización del menú del día en PDF
- Subida de PDF diaria por parte del propietario
- Diseño moderno y responsive
- Multilenguaje: Español (por defecto), Català e English

## Requisitos
- Node.js 20+
- Proyecto de Supabase con bucket de Storage (por defecto `menus`)

## Variables de entorno
Copia `.env.example` a `.env.local` y completa:

```env
NEXT_PUBLIC_SUPABASE_URL=tu_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_key
SUPABASE_SERVICE_ROLE_KEY=tu_service_key
SUPABASE_BUCKET=menus
NEXT_PUBLIC_DEFAULT_LOCALE=es
SIGNED_URL_EXPIRY=86400
ADMIN_UPLOAD_KEY=pon_aqui_una_clave_segura
```

## Scripts
- `npm run dev` – desarrollo
- `npm run build` – build producción
- `npm start` – servidor producción

## Estructura
- `/pages` – Inicio y subida de menú
- `/components` – Header, Footer, PdfViewer
- `/public` – Imágenes y locales i18n
- `/styles` – CSS global
- `/lib` – Conexión Supabase (cliente y servidor)
- `/pages/api` – Endpoints `latestMenu` y `uploadMenu`

## Supabase
- Crea un bucket (por defecto `menus`). Puedes dejarlo **privado**; el servidor genera **signed URLs** temporales.
- El endpoint `/api/uploadMenu` está protegido por `ADMIN_UPLOAD_KEY`. Introduce esa clave en la página `/upload` para subir el PDF.
- Los PDFs se guardan como `YYYY-MM-DD.pdf` para facilitar el orden cronológico.

## Despliegue (Vercel)
- Importa el repo desde GitHub en Vercel.
- Añade las variables de entorno en el proyecto de Vercel.
- Recuerda configurar `NODE_VERSION` a 20 si fuera necesario.

---
> Nota: esta plantilla está pensada para un uso sencillo por el propietario. Para acceso multiusuario o autenticación robusta, integra Supabase Auth.
